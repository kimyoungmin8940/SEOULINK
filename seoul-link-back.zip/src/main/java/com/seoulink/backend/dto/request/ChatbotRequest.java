package com.seoulink.backend.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChatbotRequest {
    @NotNull
    private Long memberId;

    @NotBlank
    @Size(max = 4000)
    private String question;

    @NotBlank
    @Size(max = 100)
    private String travelConcept;
}
